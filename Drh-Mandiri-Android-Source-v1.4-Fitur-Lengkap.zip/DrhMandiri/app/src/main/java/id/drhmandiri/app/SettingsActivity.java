package id.drhmandiri.app;

import android.content.*;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    EditText doctor,city; SharedPreferences p;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_settings);
        doctor=findViewById(R.id.edtDoctor); city=findViewById(R.id.edtCity);
        p=getSharedPreferences("settings",MODE_PRIVATE);
        findViewById(R.id.btnBackupRestore).setOnClickListener(v->startActivity(new Intent(this,BackupRestoreActivity.class)));
        findViewById(R.id.btnArchive).setOnClickListener(v->startActivity(new Intent(this,ArchiveActivity.class)));
        doctor.setText(p.getString("doctor","")); city.setText(p.getString("city","Ngawi"));
        findViewById(R.id.btnSaveSettings).setOnClickListener(v->{
            p.edit().putString("doctor",doctor.getText().toString()).putString("city",city.getText().toString()).apply();
            Toast.makeText(this,"Pengaturan tersimpan",Toast.LENGTH_SHORT).show(); finish();
        });
    }
}
