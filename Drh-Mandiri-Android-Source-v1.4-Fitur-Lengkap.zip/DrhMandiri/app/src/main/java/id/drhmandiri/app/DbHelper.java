package id.drhmandiri.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class DbHelper extends SQLiteOpenHelper {
    private static final String DB = "drh_mandiri.db";
    public DbHelper(Context c) { super(c, DB, null, 1); }

    public void replaceAll(List<ActivityRecord> records) {
        SQLiteDatabase database=getWritableDatabase(); database.beginTransaction();
        try { database.delete("activities", null, null); for(ActivityRecord r:records){ ContentValues v=new ContentValues(); v.put("date",r.date); v.put("service",r.service); v.put("location",r.location); v.put("animal",r.animal); v.put("count",r.count); v.put("note",r.note); database.insertOrThrow("activities",null,v); } database.setTransactionSuccessful(); } finally { database.endTransaction(); }
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE activities(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,service TEXT,location TEXT,animal TEXT,count INTEGER,note TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int a, int b) {}

    public long save(ActivityRecord r) {
        ContentValues v = new ContentValues();
        v.put("date", r.date);
        v.put("service", r.service);
        v.put("location", r.location);
        v.put("animal", r.animal);
        v.put("count", r.count);
        v.put("note", r.note);

        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();
        try {
            long result;
            if (r.id > 0) {
                int updated = database.update("activities", v, "id=?", new String[]{String.valueOf(r.id)});
                result = updated > 0 ? r.id : -1;
            } else {
                result = database.insert("activities", null, v);
            }

            if (result > 0) database.setTransactionSuccessful();
            return result;
        } catch (Exception e) {
            return -1;
        } finally {
            database.endTransaction();
        }
    }

    public List<ActivityRecord> all() {
        return query("SELECT * FROM activities ORDER BY substr(date,7,4)||substr(date,4,2)||substr(date,1,2) DESC, id DESC");
    }

    public List<ActivityRecord> byMonth(String mm, String yyyy) {
        return query("SELECT * FROM activities WHERE substr(date,4,2)=? AND substr(date,7,4)=? ORDER BY date ASC, id ASC",
                new String[]{mm, yyyy});
    }

    private List<ActivityRecord> query(String sql) { return query(sql, null); }
    private List<ActivityRecord> query(String sql, String[] args) {
        List<ActivityRecord> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(sql, args);
        while (c.moveToNext()) out.add(new ActivityRecord(
                c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("date")),
                c.getString(c.getColumnIndexOrThrow("service")),
                c.getString(c.getColumnIndexOrThrow("location")),
                c.getString(c.getColumnIndexOrThrow("animal")),
                c.getInt(c.getColumnIndexOrThrow("count")),
                c.getString(c.getColumnIndexOrThrow("note"))
        ));
        c.close();
        return out;
    }

    public void delete(long id) {
        getWritableDatabase().delete("activities", "id=?", new String[]{String.valueOf(id)});
    }
}
