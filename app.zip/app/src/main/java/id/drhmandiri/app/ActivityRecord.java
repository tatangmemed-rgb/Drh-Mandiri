package id.drhmandiri.app;

public class ActivityRecord {
    public long id;
    public String date, service, location, animal, note;
    public int count;

    public ActivityRecord() {}

    public ActivityRecord(long id, String date, String service, String location,
                          String animal, int count, String note) {
        this.id=id; this.date=date; this.service=service; this.location=location;
        this.animal=animal; this.count=count; this.note=note;
    }
}
