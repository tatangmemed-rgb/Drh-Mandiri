package id.drhmandiri.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.util.*;

public class ReportActivity extends AppCompatActivity {
 Spinner startMonth,endMonth; EditText startYear,endYear; TextView preview,status; DbHelper db;
 String[] months={"Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"};
 @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_report); db=new DbHelper(this);
  startMonth=findViewById(R.id.spStartMonth); endMonth=findViewById(R.id.spEndMonth); startYear=findViewById(R.id.edtStartYear); endYear=findViewById(R.id.edtEndYear); preview=findViewById(R.id.txtPreview); status=findViewById(R.id.txtSignatureStatus);
  ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,months); startMonth.setAdapter(a); endMonth.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,months));
  Calendar c=Calendar.getInstance(); startMonth.setSelection(c.get(Calendar.MONTH)); endMonth.setSelection(c.get(Calendar.MONTH)); String y=String.valueOf(c.get(Calendar.YEAR)); startYear.setText(y); endYear.setText(y);
  findViewById(R.id.btnPreview).setOnClickListener(v->showPreview()); findViewById(R.id.btnPdf).setOnClickListener(v->export("pdf")); findViewById(R.id.btnJpg).setOnClickListener(v->export("jpg")); findViewById(R.id.btnDoc).setOnClickListener(v->export("doc"));
 }
 @Override protected void onResume(){super.onResume(); File f=new File(getFilesDir(),"doctor_signature.png"); status.setText(f.exists()?"✓ Tanda tangan dokter siap digunakan pada laporan periode yang dipilih":"Tanda tangan belum dibuat. Buat melalui menu Tanda Tangan Dokter Hewan.");}
 private List<ReportExporter.MonthReport> reports(){ int sy=Integer.parseInt(startYear.getText().toString().trim()), ey=Integer.parseInt(endYear.getText().toString().trim()); int sm=startMonth.getSelectedItemPosition(), em=endMonth.getSelectedItemPosition(); if(sy>ey||(sy==ey&&sm>em)) throw new IllegalArgumentException("Periode mulai harus sebelum atau sama dengan periode selesai."); List<ReportExporter.MonthReport> out=new ArrayList<>(); for(int y=sy;y<=ey;y++){ int from=(y==sy?sm:0), to=(y==ey?em:11); for(int m=from;m<=to;m++){ out.add(new ReportExporter.MonthReport(months[m],String.valueOf(y),db.byMonth(String.format(Locale.US,"%02d",m+1),String.valueOf(y)))); }} return out; }
 private void showPreview(){ try{ List<ReportExporter.MonthReport> rs=reports(); StringBuilder s=new StringBuilder(); for(ReportExporter.MonthReport mr:rs){ s.append("=== ").append(mr.month.toUpperCase()).append(" ").append(mr.year).append(" (HALAMAN BARU) ===\n"); if(mr.data.isEmpty())s.append("Belum ada data.\n\n"); else {int n=1; for(ActivityRecord r:mr.data)s.append(n++).append(". ").append(r.service).append("\n   ").append(r.location).append(" | ").append(r.animal).append(" | ").append(r.count).append(" ekor\n   ").append(r.note==null?"":r.note).append("\n"); s.append("\n");}} preview.setText(s.toString()); }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}
 private void export(String type){ try{ List<ReportExporter.MonthReport> rs=reports(); SharedPreferences p=getSharedPreferences("settings",MODE_PRIVATE); String doctor=p.getString("doctor","Dokter Hewan"), city=p.getString("city","Ngawi"); File sig=new File(getFilesDir(),"doctor_signature.png"); File out=ReportExporter.export(this,type,rs,city,doctor,sig.exists()?sig:null); ReportExporter.share(this,out,type); }catch(Exception e){Toast.makeText(this,"Gagal export: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
}
