package id.drhmandiri.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class ReportActivity extends AppCompatActivity {
    Spinner month; EditText year; TextView preview; DbHelper db;
    String[] months={"Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"};

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_report); db=new DbHelper(this);
        month=findViewById(R.id.spMonth); year=findViewById(R.id.edtYear); preview=findViewById(R.id.txtPreview);
        month.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,months));
        Calendar c=Calendar.getInstance(); month.setSelection(c.get(Calendar.MONTH)); year.setText(String.valueOf(c.get(Calendar.YEAR)));
        findViewById(R.id.btnPreview).setOnClickListener(v->showPreview());
        findViewById(R.id.btnPdf).setOnClickListener(v->export("pdf"));
        findViewById(R.id.btnJpg).setOnClickListener(v->export("jpg"));
        findViewById(R.id.btnDoc).setOnClickListener(v->export("doc"));
    }
    List<ActivityRecord> records(){
        String mm=String.format(Locale.US,"%02d",month.getSelectedItemPosition()+1);
        return db.byMonth(mm,year.getText().toString());
    }
    void showPreview(){
        List<ActivityRecord> r=records();
        StringBuilder s=new StringBuilder("LAPORAN KEGIATAN DOKTER HEWAN MANDIRI\nBULAN: "+months[month.getSelectedItemPosition()].toUpperCase()+"\nTAHUN: "+year.getText()+"\n\n");
        int no=1; for(ActivityRecord x:r) s.append(no++).append(". ").append(x.service).append("\n   ").append(x.location).append(" | ").append(x.animal).append(" | ").append(x.count).append(" ekor\n   ").append(x.note).append("\n\n");
        if(r.isEmpty()) s.append("Belum ada data untuk periode ini.");
        preview.setText(s.toString());
    }
    void export(String type){
        try{
            List<ActivityRecord> r=records();
            SharedPreferences p=getSharedPreferences("settings",MODE_PRIVATE);
            String doctor=p.getString("doctor","Dokter Hewan");
            String city=p.getString("city","Ngawi");
            java.io.File out=ReportExporter.export(this,type,months[month.getSelectedItemPosition()],year.getText().toString(),r,city,doctor);
            ReportExporter.share(this,out,type);
        }catch(Exception e){ Toast.makeText(this,"Gagal export: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }
}
