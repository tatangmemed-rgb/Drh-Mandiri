package id.drhmandiri.app;

import android.app.AlertDialog;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.*;

public class SettingsActivity extends AppCompatActivity {
    private static final int REQ_BACKUP = 701;
    private static final int REQ_RESTORE = 702;
    EditText doctor,city; SharedPreferences p;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_settings);
        doctor=findViewById(R.id.edtDoctor); city=findViewById(R.id.edtCity);
        p=getSharedPreferences("settings",MODE_PRIVATE);
        doctor.setText(p.getString("doctor","")); city.setText(p.getString("city","Ngawi"));
        findViewById(R.id.btnSaveSettings).setOnClickListener(v->{
            p.edit().putString("doctor",doctor.getText().toString()).putString("city",city.getText().toString()).apply();
            Toast.makeText(this,"Pengaturan tersimpan",Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnBackup).setOnClickListener(v->createBackup());
        findViewById(R.id.btnRestore).setOnClickListener(v->chooseRestore());
    }

    private void createBackup(){
        String date = new SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(new Date());
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType("application/zip");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_TITLE, "Backup_Drh_Mandiri_" + date + ".zip");
        startActivityForResult(i, REQ_BACKUP);
    }

    private void chooseRestore(){
        new AlertDialog.Builder(this)
            .setTitle("Restore Data")
            .setMessage("Data kegiatan dan pengaturan yang ada akan diganti dengan data dari file backup. Lanjutkan?")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Pilih File", (d,w)->{
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.setType("application/zip");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(i, REQ_RESTORE);
            }).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if(requestCode == REQ_BACKUP){
            try {
                BackupManager.backup(this, uri);
                Toast.makeText(this,"Backup berhasil disimpan",Toast.LENGTH_LONG).show();
            } catch(Exception e){ Toast.makeText(this,"Backup gagal: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
        } else if(requestCode == REQ_RESTORE){
            try {
                new DbHelper(this).close();
                BackupManager.restore(this, uri);
                Toast.makeText(this,"Restore berhasil. Tutup lalu buka kembali aplikasi.",Toast.LENGTH_LONG).show();
            } catch(Exception e){ Toast.makeText(this,"Restore gagal: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
        }
    }
}
