package id.drhmandiri.app;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.*;

public class AddEditActivity extends AppCompatActivity {
    EditText date, service, location, animal, count, note;
    Button btnSave;
    long id = 0;
    DbHelper db;
    boolean saving = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_add_edit);
        db = new DbHelper(this);

        date = findViewById(R.id.edtDate);
        service = findViewById(R.id.edtService);
        location = findViewById(R.id.edtLocation);
        animal = findViewById(R.id.edtAnimal);
        count = findViewById(R.id.edtCount);
        note = findViewById(R.id.edtNote);
        btnSave = findViewById(R.id.btnSave);

        date.setText(new SimpleDateFormat("dd/MM/yyyy", Locale.US).format(new Date()));
        date.setOnClickListener(v -> pickDate());

        id = getIntent().getLongExtra("id", 0);
        if (id > 0) {
            ActivityRecord r = null;
            for (ActivityRecord x : db.all()) if (x.id == id) r = x;
            if (r != null) {
                date.setText(r.date);
                service.setText(r.service);
                location.setText(r.location);
                animal.setText(r.animal);
                count.setText(String.valueOf(r.count));
                note.setText(r.note);
            }
            ((TextView) findViewById(R.id.title)).setText("Edit Kegiatan");
        }

        btnSave.setOnClickListener(v -> save());
    }

    void pickDate() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (view, y, m, d) ->
                date.setText(String.format(Locale.US, "%02d/%02d/%04d", d, m + 1, y)),
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    void save() {
        if (saving) return;

        String serviceText = service.getText().toString().trim();
        if (serviceText.isEmpty()) {
            service.setError("Wajib diisi");
            service.requestFocus();
            return;
        }

        int n = 0;
        String countText = count.getText().toString().trim();
        if (!countText.isEmpty()) {
            try {
                n = Integer.parseInt(countText);
                if (n < 0) throw new NumberFormatException();
            } catch (Exception e) {
                count.setError("Jumlah hewan tidak valid");
                count.requestFocus();
                return;
            }
        }

        saving = true;
        btnSave.setEnabled(false);
        btnSave.setText("Menyimpan...");

        ActivityRecord r = new ActivityRecord(
                id,
                date.getText().toString().trim(),
                serviceText,
                location.getText().toString().trim(),
                animal.getText().toString().trim(),
                n,
                note.getText().toString().trim()
        );

        long savedId = db.save(r);
        if (savedId > 0) {
            id = savedId;
            setResult(RESULT_OK);
            Toast.makeText(this, "Kegiatan berhasil tersimpan", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            saving = false;
            btnSave.setEnabled(true);
            btnSave.setText("Simpan");
            Toast.makeText(this, "Gagal menyimpan kegiatan. Silakan coba lagi.", Toast.LENGTH_LONG).show();
        }
    }
}
