package id.drhmandiri.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class Store {
    private static final String P="drh_store", K="activities";
    public static ArrayList<JSONObject> list(Context c){
        ArrayList<JSONObject> out=new ArrayList<>();
        try{
            JSONArray a=new JSONArray(c.getSharedPreferences(P,0).getString(K,"[]"));
            for(int i=0;i<a.length();i++) out.add(a.getJSONObject(i));
        }catch(Exception ignored){}
        return out;
    }
    public static void save(Context c, ArrayList<JSONObject> a){
        JSONArray x=new JSONArray(); for(JSONObject o:a)x.put(o);
        c.getSharedPreferences(P,0).edit().putString(K,x.toString()).apply();
    }
    public static void add(Context c,String name,String source,String uri){
        try{
            ArrayList<JSONObject>a=list(c); JSONObject o=new JSONObject();
            o.put("name",name); o.put("source",source); o.put("uri",uri);
            o.put("date",new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date()));
            a.add(o); save(c,a);
        }catch(Exception ignored){}
    }
}
