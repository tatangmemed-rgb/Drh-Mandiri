package id.drhmandiri.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import org.json.JSONObject;
import java.io.*;
import java.util.zip.*;

public class BackupManager {
    private static final String DB_NAME = "drh_mandiri.db";
    private static final String SIG_NAME = "doctor_signature.png";

    public static void backup(Context context, Uri uri) throws Exception {
        try (OutputStream os = context.getContentResolver().openOutputStream(uri);
             ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(os))) {

            JSONObject meta = new JSONObject();
            meta.put("app", "Drh Mandiri");
            meta.put("format", 1);
            meta.put("created_at", System.currentTimeMillis());
            putText(zos, "backup.json", meta.toString());

            SharedPreferences p = context.getSharedPreferences("settings", Context.MODE_PRIVATE);
            JSONObject settings = new JSONObject();
            settings.put("doctor", p.getString("doctor", ""));
            settings.put("city", p.getString("city", "Ngawi"));
            settings.put("signature_saved", p.getBoolean("signature_saved", false));
            putText(zos, "settings.json", settings.toString());

            File db = context.getDatabasePath(DB_NAME);
            if (db.exists()) putFile(zos, "drh_mandiri.db", db);

            File sig = new File(context.getFilesDir(), SIG_NAME);
            if (sig.exists()) putFile(zos, SIG_NAME, sig);
        }
    }

    public static void restore(Context context, Uri uri) throws Exception {
        File tempDir = new File(context.getCacheDir(), "restore_" + System.currentTimeMillis());
        if (!tempDir.mkdirs()) throw new IOException("Tidak dapat membuat folder sementara");
        File dbOut = null, sigOut = null, settingsOut = null;
        try (InputStream is = context.getContentResolver().openInputStream(uri);
             ZipInputStream zis = new ZipInputStream(new BufferedInputStream(is))) {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                String name = e.getName();
                if ("drh_mandiri.db".equals(name)) dbOut = copyEntry(zis, new File(tempDir, name));
                else if (SIG_NAME.equals(name)) sigOut = copyEntry(zis, new File(tempDir, name));
                else if ("settings.json".equals(name)) settingsOut = copyEntry(zis, new File(tempDir, name));
                zis.closeEntry();
            }
        }
        if (dbOut == null) throw new IOException("File database tidak ditemukan dalam backup");

        SQLiteDatabase database = context.openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE, null);
        database.close();
        File targetDb = context.getDatabasePath(DB_NAME);
        File wal = new File(targetDb.getPath() + "-wal");
        File shm = new File(targetDb.getPath() + "-shm");
        wal.delete(); shm.delete();
        copyFile(dbOut, targetDb);

        if (sigOut != null) copyFile(sigOut, new File(context.getFilesDir(), SIG_NAME));
        else new File(context.getFilesDir(), SIG_NAME).delete();

        SharedPreferences.Editor ed = context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().clear();
        if (settingsOut != null) {
            String json = readText(settingsOut);
            JSONObject s = new JSONObject(json);
            ed.putString("doctor", s.optString("doctor", ""));
            ed.putString("city", s.optString("city", "Ngawi"));
            ed.putBoolean("signature_saved", s.optBoolean("signature_saved", false));
        }
        ed.apply();
    }

    private static void putText(ZipOutputStream zos, String name, String text) throws IOException {
        zos.putNextEntry(new ZipEntry(name));
        zos.write(text.getBytes("UTF-8"));
        zos.closeEntry();
    }
    private static void putFile(ZipOutputStream zos, String name, File file) throws IOException {
        zos.putNextEntry(new ZipEntry(name));
        try (InputStream in = new FileInputStream(file)) { copy(in, zos); }
        zos.closeEntry();
    }
    private static File copyEntry(InputStream in, File out) throws IOException {
        try (OutputStream os = new FileOutputStream(out)) { copy(in, os); }
        return out;
    }
    private static void copyFile(File from, File to) throws IOException {
        try (InputStream in = new FileInputStream(from); OutputStream out = new FileOutputStream(to)) { copy(in, out); }
    }
    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[8192]; int n; while ((n = in.read(b)) != -1) out.write(b, 0, n);
    }
    private static String readText(File f) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream in = new FileInputStream(f)) { copy(in, out); }
        return out.toString("UTF-8");
    }
}
