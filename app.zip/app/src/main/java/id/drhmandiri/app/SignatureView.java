package id.drhmandiri.app;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class SignatureView extends View {
    private final Path path = new Path();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Bitmap bitmap;
    private Canvas bitmapCanvas;
    private float lastX, lastY;

    public SignatureView(Context c, AttributeSet a) { super(c,a); init(); }
    public SignatureView(Context c) { super(c); init(); }
    private void init(){ paint.setColor(Color.BLACK); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(6f); paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND); setBackgroundColor(Color.WHITE); }
    @Override protected void onSizeChanged(int w,int h,int ow,int oh){ super.onSizeChanged(w,h,ow,oh); if(w>0&&h>0){ Bitmap old=bitmap; bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); bitmapCanvas=new Canvas(bitmap); bitmapCanvas.drawColor(Color.WHITE); if(old!=null) bitmapCanvas.drawBitmap(old,0,0,null); }}
    @Override protected void onDraw(Canvas c){ super.onDraw(c); if(bitmap!=null)c.drawBitmap(bitmap,0,0,null); c.drawPath(path,paint); }
    @Override public boolean onTouchEvent(MotionEvent e){ float x=e.getX(), y=e.getY(); switch(e.getAction()){ case MotionEvent.ACTION_DOWN: path.moveTo(x,y); lastX=x; lastY=y; return true; case MotionEvent.ACTION_MOVE: path.quadTo(lastX,lastY,(x+lastX)/2,(y+lastY)/2); lastX=x; lastY=y; invalidate(); return true; case MotionEvent.ACTION_UP: path.lineTo(x,y); if(bitmapCanvas!=null){ bitmapCanvas.drawPath(path,paint); path.reset(); } invalidate(); return true; } return true; }
    public void clear(){ if(bitmapCanvas!=null)bitmapCanvas.drawColor(Color.WHITE); path.reset(); invalidate(); }
    public boolean savePng(java.io.File f){ try{ if(bitmap==null)return false; java.io.FileOutputStream o=new java.io.FileOutputStream(f); boolean ok=bitmap.compress(Bitmap.CompressFormat.PNG,100,o); o.close(); return ok; }catch(Exception e){return false;} }
}
