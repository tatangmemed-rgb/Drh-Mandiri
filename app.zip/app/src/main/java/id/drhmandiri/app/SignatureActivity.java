package id.drhmandiri.app;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;

public class SignatureActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_signature); SignatureView pad=findViewById(R.id.signaturePad); findViewById(R.id.btnClearSignature).setOnClickListener(v->pad.clear()); findViewById(R.id.btnSaveSignature).setOnClickListener(v->{ File f=new File(getFilesDir(),"doctor_signature.png"); if(pad.savePng(f)){ getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("signature_saved",true).apply(); Toast.makeText(this,"Tanda tangan tersimpan",Toast.LENGTH_SHORT).show(); finish(); }else Toast.makeText(this,"Gagal menyimpan tanda tangan",Toast.LENGTH_LONG).show(); }); }
}
