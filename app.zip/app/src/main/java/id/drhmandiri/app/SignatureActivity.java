package id.drhmandiri.app;
import android.app.*;import android.os.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import java.io.*;import android.util.Base64;
public class SignatureActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(20,20,20,20);
 TextView t=new TextView(this);t.setText("Tanda Tangan Dokter Hewan");t.setTextSize(26);l.addView(t);Sig s=new Sig();l.addView(s,new LinearLayout.LayoutParams(-1,500));
 LinearLayout x=new LinearLayout(this);Button clear=new Button(this);clear.setText("Hapus");Button save=new Button(this);save.setText("Simpan Tanda Tangan");x.addView(clear,new LinearLayout.LayoutParams(0,-2,1));x.addView(save,new LinearLayout.LayoutParams(0,-2,1));l.addView(x);setContentView(l);
 clear.setOnClickListener(v->s.clear());save.setOnClickListener(v->{Bitmap bm=s.bitmap();ByteArrayOutputStream o=new ByteArrayOutputStream();bm.compress(Bitmap.CompressFormat.PNG,100,o);getSharedPreferences("drh_store",0).edit().putString("signature",Base64.encodeToString(o.toByteArray(),0)).apply();Toast.makeText(this,"Tanda tangan disimpan",Toast.LENGTH_SHORT).show();finish();});
 }
 static class Sig extends View{Paint p=new Paint(1);Path path=new Path();Sig(){super(SignatureActivity.this);p.setColor(Color.DKGRAY);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);setBackgroundColor(Color.WHITE);}protected void onDraw(Canvas c){c.drawPath(path,p);}public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY();if(e.getAction()==0)path.moveTo(x,y);else if(e.getAction()==2)path.lineTo(x,y);invalidate();return true;}void clear(){path.reset();invalidate();}Bitmap bitmap(){Bitmap b=Bitmap.createBitmap(getWidth(),getHeight(),Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);c.drawColor(Color.WHITE);c.drawPath(path,p);return b;}}
}
