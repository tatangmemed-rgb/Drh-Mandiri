package id.drhmandiri.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class DataActivity extends AppCompatActivity {
    DbHelper db; List<ActivityRecord> data=new ArrayList<>(); ArrayAdapter<String> adapter;
    @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_data); db=new DbHelper(this); }
    @Override protected void onResume(){ super.onResume(); load(); }
    void load(){
        data=db.all(); List<String> rows=new ArrayList<>();
        for(ActivityRecord r:data) rows.add(r.date+"\n"+r.service+" | "+r.location+" | "+r.animal+" ("+r.count+")");
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_2,android.R.id.text1,rows){
            @Override public View getView(int p,View v,android.view.ViewGroup parent){
                View row=super.getView(p,v,parent);
                TextView t1=row.findViewById(android.R.id.text1), t2=row.findViewById(android.R.id.text2);
                ActivityRecord r=data.get(p); t1.setText(r.date+" — "+r.service); t2.setText(r.location+" | "+r.animal+" | "+r.count+" ekor");
                return row;
            }
        };
        ListView list=findViewById(R.id.listData); list.setAdapter(adapter);
        list.setOnItemClickListener((a,v,p,i)->{
            Intent in=new Intent(this,AddEditActivity.class); in.putExtra("id",data.get(p).id); startActivity(in);
        });
        list.setOnItemLongClickListener((a,v,p,i)->{
            ActivityRecord r=data.get(p);
            new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Hapus kegiatan?").setMessage(r.service)
                .setPositiveButton("Hapus",(d,w)->{db.delete(r.id);load();})
                .setNegativeButton("Batal",null).show();
            return true;
        });
    }
}
