package id.drhmandiri.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        findViewById(R.id.btnAdd).setOnClickListener(v->startActivity(new Intent(this,AddEditActivity.class)));
        findViewById(R.id.btnData).setOnClickListener(v->startActivity(new Intent(this,DataActivity.class)));
        findViewById(R.id.btnReport).setOnClickListener(v->startActivity(new Intent(this,ReportActivity.class)));
        findViewById(R.id.btnSignature).setOnClickListener(v->startActivity(new Intent(this,SignatureActivity.class)));
        findViewById(R.id.btnSettings).setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
    }
}
