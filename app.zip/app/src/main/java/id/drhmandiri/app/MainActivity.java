package id.drhmandiri.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK=91;
    LinearLayout root;
    int green=Color.rgb(46,107,87);
    public void onCreate(Bundle b){super.onCreate(b); showHome();}
    int dp(int value){ return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    TextView tv(String s,int size){
        TextView v=new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(Color.DKGRAY);
        v.setPadding(0,dp(10),0,dp(10));
        return v;
    }

    Button btn(String s){
        Button b=new Button(this);
        b.setText(s);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setMinHeight(dp(56));
        b.setMinimumHeight(dp(56));
        b.setIncludeFontPadding(true);
        b.setBackgroundColor(green);
        b.setPadding(dp(16),dp(8),dp(16),dp(8));

        // Gunakan satuan dp, bukan pixel mentah.
        // Tinggi WRAP_CONTENT + minimum 56dp mencegah teks/tombol saling menumpuk.
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        p.setMargins(0,dp(6),0,dp(6));
        b.setLayoutParams(p);
        return b;
    }
    void showHome(){
        ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(24),dp(20),dp(24));sv.addView(root); setContentView(sv);
        TextView title=tv("Drh Mandiri",42);title.setTextColor(green);title.setTypeface(null,1);root.addView(title);
        root.addView(tv("Laporan Kegiatan Dokter Hewan\nMandiri",28));
        Button add=btn("+ Tambah Kegiatan"); add.setOnClickListener(v->manual()); root.addView(add);
        Button data=btn("☷ Data Kegiatan ("+Store.list(this).size()+")");data.setOnClickListener(v->data());root.addView(data);
        Button imp=btn("⇩ Import File Kegiatan");imp.setOnClickListener(v->pick());root.addView(imp);
        Button report=btn("▣ Buat Laporan");report.setOnClickListener(v->startActivity(new Intent(this,ReportActivity.class)));root.addView(report);
        Button sign=btn("✍ Tanda Tangan Dokter Hewan");sign.setOnClickListener(v->startActivity(new Intent(this,SignatureActivity.class)));root.addView(sign);
        Button set=btn("⚙ Pengaturan Dokter");set.setOnClickListener(v->doctor());root.addView(set);
        root.addView(tv("Data disimpan di perangkat dan dapat diedit kapan saja.",20));
    }
    void manual(){
        final EditText e=new EditText(this);e.setHint("Nama / uraian kegiatan");
        new AlertDialog.Builder(this).setTitle("Tambah Kegiatan").setView(e).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{if(e.getText().length()>0){Store.add(this,e.getText().toString(),"Manual","");showHome();}}).show();
    }
    void data(){
        ArrayList<org.json.JSONObject>a=Store.list(this); StringBuilder s=new StringBuilder();
        for(int i=0;i<a.size();i++)try{s.append(i+1).append(". ").append(a.get(i).getString("name")).append("\n   ").append(a.get(i).optString("source")).append(" • ").append(a.get(i).optString("date")).append("\n\n");}catch(Exception ignored){}
        new AlertDialog.Builder(this).setTitle("Daftar Kegiatan").setMessage(s.length()==0?"Belum ada kegiatan.":s.toString()).setPositiveButton("OK",null).show();
    }
    void doctor(){
        final EditText e=new EditText(this);e.setHint("Nama Dokter Hewan");
        new AlertDialog.Builder(this).setTitle("Pengaturan Dokter").setView(e).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->getSharedPreferences("drh_store",0).edit().putString("doctor",e.getText().toString()).apply()).show();
    }
    void pick(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/jpeg","image/jpg","application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document"});
        startActivityForResult(i,PICK);
    }
    protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK&&c==RESULT_OK&&d!=null){
        Uri u=d.getData(); try{getContentResolver().takePersistableUriPermission(u,d.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));}catch(Exception ignored){}
        String n="File impor";try(android.database.Cursor q=getContentResolver().query(u,null,null,null,null)){if(q!=null&&q.moveToFirst()){int x=q.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(x>=0)n=q.getString(x);}}
        Store.add(this,n,"Import File",u.toString());
        Toast.makeText(this,"File masuk ke Daftar Kegiatan. Membuka Buat Laporan…",Toast.LENGTH_LONG).show();
        startActivity(new Intent(this,ReportActivity.class));
    }}
}
