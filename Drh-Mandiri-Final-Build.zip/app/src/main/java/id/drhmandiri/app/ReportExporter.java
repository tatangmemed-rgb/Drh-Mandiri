package id.drhmandiri.app;

import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class ReportExporter {
    private static final int W=1240, H=1754;

    public static File export(Context c,String type,String month,String year,List<ActivityRecord> data,String city,String doctor) throws Exception {
        File dir=new File(c.getCacheDir(),"reports"); if(!dir.exists()) dir.mkdirs();
        String base="Laporan_Drh_Mandiri_"+month+"_"+year;
        if(type.equals("pdf")) return pdf(dir,base,month,year,data,city,doctor);
        if(type.equals("jpg")) return jpg(dir,base,month,year,data,city,doctor);
        return doc(dir,base,month,year,data,city,doctor);
    }

    private static void draw(Canvas canvas, String month,String year,List<ActivityRecord> data,String city,String doctor){
        canvas.drawColor(Color.WHITE);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK);
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD)); p.setTextSize(28);
        canvas.drawText("LAPORAN KEGIATAN DOKTER HEWAN MANDIRI",W/2,70,p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(24);
        canvas.drawText("BULAN : "+month.toUpperCase(),W/2,110,p);
        canvas.drawText("TAHUN : "+year,W/2,145,p);

        int x=60,y=190,rowH=58;
        int[] xs={60,120,470,760,900,1030,1180};
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(17);
        String[] head={"No.","Jenis Pelayanan / Penyakit","Lokasi (Desa/Kecamatan)","Jenis Hewan","Jumlah Hewan","Keterangan"};
        for(int i=0;i<6;i++) canvas.drawRect(xs[i],y,xs[i+1],y+rowH,p);
        p.setStyle(Paint.Style.FILL);
        for(int i=0;i<6;i++) canvas.drawText(head[i],(xs[i]+xs[i+1])/2,y+35,p);

        int no=1;
        p.setTextSize(15); p.setTextAlign(Paint.Align.LEFT);
        for(ActivityRecord r:data){
            if(y+2*rowH>H-300) break;
            y+=rowH;
            for(int i=0;i<6;i++){p.setStyle(Paint.Style.STROKE);canvas.drawRect(xs[i],y,xs[i+1],y+rowH,p);}
            p.setStyle(Paint.Style.FILL);
            String[] vals={String.valueOf(no++),r.service,r.location,r.animal,String.valueOf(r.count),r.note};
            for(int i=0;i<6;i++){
                String s=vals[i]==null?"":vals[i];
                canvas.save(); canvas.clipRect(xs[i]+4,y+3,xs[i+1]-4,y+rowH-3);
                canvas.drawText(s,xs[i]+6,y+35,p); canvas.restore();
            }
        }
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(20);
        String today=new SimpleDateFormat("dd MMMM yyyy",new Locale("id","ID")).format(new Date());
        canvas.drawText(city+", "+today,W-250,H-180,p);
        canvas.drawText("Dokter Hewan",W-250,H-145,p);
        p.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
        canvas.drawText(doctor,W-250,H-55,p);
    }

    private static File jpg(File dir,String base,String month,String year,List<ActivityRecord> data,String city,String doctor)throws Exception{
        Bitmap b=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888); draw(new Canvas(b),month,year,data,city,doctor);
        File f=new File(dir,base+".jpg"); FileOutputStream o=new FileOutputStream(f); b.compress(Bitmap.CompressFormat.JPEG,95,o); o.close(); return f;
    }

    private static File pdf(File dir,String base,String month,String year,List<ActivityRecord> data,String city,String doctor)throws Exception{
        PdfDocument d=new PdfDocument(); PdfDocument.Page page=d.startPage(new PdfDocument.PageInfo.Builder(W,H,1).create());
        draw(page.getCanvas(),month,year,data,city,doctor); d.finishPage(page);
        File f=new File(dir,base+".pdf"); FileOutputStream o=new FileOutputStream(f); d.writeTo(o); o.close(); d.close(); return f;
    }

    private static String esc(String s){return s==null?"":s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");}
    private static File doc(File dir,String base,String month,String year,List<ActivityRecord> data,String city,String doctor)throws Exception{
        StringBuilder h=new StringBuilder("<html><head><meta charset='UTF-8'></head><body style='font-family:Arial'>");
        h.append("<div style='text-align:center'><b>LAPORAN KEGIATAN DOKTER HEWAN MANDIRI</b><br>BULAN : ").append(month.toUpperCase()).append("<br>TAHUN : ").append(year).append("</div><br>");
        h.append("<table border='1' cellspacing='0' cellpadding='5' width='100%'><tr><th>No.</th><th>Jenis Pelayanan / Penyakit</th><th>Lokasi (Desa/Kecamatan)</th><th>Jenis Hewan</th><th>Jumlah Hewan</th><th>Keterangan</th></tr>");
        int n=1; for(ActivityRecord r:data) h.append("<tr><td>").append(n++).append("</td><td>").append(esc(r.service)).append("</td><td>").append(esc(r.location)).append("</td><td>").append(esc(r.animal)).append("</td><td>").append(r.count).append("</td><td>").append(esc(r.note)).append("</td></tr>");
        String today=new SimpleDateFormat("dd MMMM yyyy",new Locale("id","ID")).format(new Date());
        h.append("</table><br><div style='text-align:right'>").append(esc(city)).append(", ").append(today).append("<br>Dokter Hewan<br><br><br><b>").append(esc(doctor)).append("</b></div></body></html>");
        File f=new File(dir,base+".doc"); FileOutputStream o=new FileOutputStream(f); o.write(h.toString().getBytes("UTF-8")); o.close(); return f;
    }

    public static void share(Context c,File f,String type){
        Uri u=FileProvider.getUriForFile(c,c.getPackageName()+".provider",f);
        String mime=type.equals("pdf")?"application/pdf":type.equals("jpg")?"image/jpeg":"application/msword";
        Intent i=new Intent(Intent.ACTION_SEND); i.setType(mime); i.putExtra(Intent.EXTRA_STREAM,u); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        c.startActivity(Intent.createChooser(i,"Bagikan laporan"));
    }
}
