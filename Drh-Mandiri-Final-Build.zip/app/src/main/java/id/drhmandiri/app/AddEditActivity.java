package id.drhmandiri.app;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.*;

public class AddEditActivity extends AppCompatActivity {
    EditText date,service,location,animal,count,note; long id=0; DbHelper db;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_add_edit); db=new DbHelper(this);
        date=findViewById(R.id.edtDate); service=findViewById(R.id.edtService); location=findViewById(R.id.edtLocation);
        animal=findViewById(R.id.edtAnimal); count=findViewById(R.id.edtCount); note=findViewById(R.id.edtNote);
        date.setText(new SimpleDateFormat("dd/MM/yyyy", Locale.US).format(new Date()));
        date.setOnClickListener(v->pickDate());
        id=getIntent().getLongExtra("id",0);
        if(id>0){
            ActivityRecord r=null; for(ActivityRecord x:db.all()) if(x.id==id) r=x;
            if(r!=null){ date.setText(r.date);service.setText(r.service);location.setText(r.location);animal.setText(r.animal);count.setText(String.valueOf(r.count));note.setText(r.note); }
            ((TextView)findViewById(R.id.title)).setText("Edit Kegiatan");
        }
        findViewById(R.id.btnSave).setOnClickListener(v->save());
    }
    void pickDate(){
        Calendar c=Calendar.getInstance();
        new DatePickerDialog(this,(view,y,m,d)->date.setText(String.format(Locale.US,"%02d/%02d/%04d",d,m+1,y)),
            c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }
    void save(){
        if(service.getText().toString().trim().isEmpty()){ service.setError("Wajib diisi"); return; }
        int n=0; try{ n=Integer.parseInt(count.getText().toString()); }catch(Exception ignored){}
        ActivityRecord r=new ActivityRecord(id,date.getText().toString(),service.getText().toString(),
            location.getText().toString(),animal.getText().toString(),n,note.getText().toString());
        db.save(r); Toast.makeText(this,"Kegiatan tersimpan",Toast.LENGTH_SHORT).show(); finish();
    }
}
